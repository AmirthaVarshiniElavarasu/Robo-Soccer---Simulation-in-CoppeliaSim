"use strict";

// Handle both Node.js and Browser environments
let WebSocketAsPromised, CBOR, WebSocket;

if (typeof window !== 'undefined') {
    // Browser environment - try different ways to access WebSocketAsPromised
    console.log('Browser environment detected');
    
    // Try global window properties first
    WebSocketAsPromised = window.WebSocketAsPromised || window.WsAsPromised;
    
    // If not found and require is available (from bundle), try require
    if (!WebSocketAsPromised && typeof require !== 'undefined') {
        try {
            // The bundle file might make require available globally
            WebSocketAsPromised = require('websocket-as-promised');
        } catch (e) {
            console.warn('Could not require websocket-as-promised:', e.message);
        }
    }
    
    CBOR = window.CBOR;
    WebSocket = window.WebSocket || window.MozWebSocket;
    
    console.log('WebSocketAsPromised available:', !!WebSocketAsPromised);
    console.log('CBOR available:', !!CBOR);
} else {
    // Node.js environment
    WebSocketAsPromised = require('websocket-as-promised');
    CBOR = require('cbor-js');
    WebSocket = require('ws');
}

class RemoteAPIClient {
    constructor(host, port, codec = "cbor", opts = {}) {
        this.host = host;
        this.port = port;
        this.codec = codec;
        this.isSecure = opts.secure || host.startsWith('https://') || host.includes('.ngrok') || host.includes('.tunnel');
        var packMessage;
        var unpackMessage;
        if(this.codec == 'cbor') {
            //this.websocket.binaryType = "arraybuffer";
            packMessage = data => CBOR.encode(data);
            if (typeof window !== 'undefined') {
                // Browser environment
                unpackMessage = async data => CBOR.decode(await data.arrayBuffer());
            } else {
                // Node.js environment - convert Buffer to ArrayBuffer
                unpackMessage = data => {
                    if (Buffer.isBuffer(data)) {
                        // Convert Buffer to ArrayBuffer
                        const arrayBuffer = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
                        return CBOR.decode(arrayBuffer);
                    }
                    return CBOR.decode(data);
                };
            }
        } else if(this.codec == "json") {
            packMessage = data => JSON.stringify(data);
            unpackMessage = data => JSON.parse(data);
        }
        var wsOpts = {
            packMessage,
            unpackMessage,
            // attach requestId to message as `id` field
            attachRequestId: (data, requestId) => Object.assign({id: requestId}, data),
            // read requestId from message `id` field
            extractRequestId: data => data && data.id,
        };
        
        // Add createWebSocket for Node.js environment only
        if (typeof window === 'undefined') {
            wsOpts.createWebSocket = url => new WebSocket(url);
        } else {
            // Browser environment - add headers for ngrok
            if (this.host.includes('ngrok')) {
                wsOpts.createWebSocket = url => {
                    // For ngrok tunnels, we need to handle headers differently
                    return new WebSocket(url);
                };
            }
        }
        for(var k in opts)
            wsOpts[k] = opts[k];
        
        // Build WebSocket URL
        const wsUrl = this.buildWebSocketUrl();
        console.log(`Attempting to connect to: ${wsUrl}`);
        
        this.websocket = new WebSocketAsPromised(wsUrl, wsOpts);
        this.connected = false;
        
        // Add connection event handlers
        this.websocket.onOpen.addListener(() => {
            this.connected = true;
            console.log('✅ WebSocket connected successfully');
        });
        
        this.websocket.onClose.addListener(() => {
            this.connected = false;
            console.log('❌ WebSocket connection closed');
        });
        
        this.websocket.onError.addListener((error) => {
            this.connected = false;
            console.error('❌ WebSocket error:', error);
        });
            // this.websocket = new WebSocketAsPromised(url, wsOpts);
    }

    buildWebSocketUrl() {
        // Handle tunnel URLs (ngrok, etc.)
        if (this.host.startsWith('http://') || this.host.startsWith('https://')) {
            // Remove http/https prefix and use appropriate ws/wss
            const cleanHost = this.host.replace(/^https?:\/\//, '');
            const protocol = this.isSecure ? 'wss://' : 'ws://';
            return `${protocol}${cleanHost}`;
        }
        
        // Handle direct domain/IP with auto-detection
        if (this.isSecure) {
            return `wss://${this.host}`;
        } else {
            return `ws://${this.host}:${this.port}`;
        }
    }

    // Connection verification methods
    async connect() {
        try {
            await this.websocket.open();
            return true;
        } catch (error) {
            console.error('Failed to connect:', error);
            return false;
        }
    }

    async disconnect() {
        if (this.websocket) {
            await this.websocket.close();
        }
    }

    isConnected() {
        return this.connected && this.websocket.ws && this.websocket.ws.readyState === 1; // WebSocket.OPEN = 1
    }

    async testConnection() {
        try {
            console.log('🔍 Testing connection...');
            const startTime = Date.now();
            
            // Try to connect
            const connected = await this.connect();
            if (!connected) {
                throw new Error('Failed to establish connection');
            }

            // Test basic API call
            const result = await this.call('wsRemoteApi.info', []);
            const responseTime = Date.now() - startTime;
            
            console.log(`✅ Connection test successful! Response time: ${responseTime}ms`);
            console.log('API Response:', result);
            return { success: true, responseTime, result };
        } catch (error) {
            console.error('❌ Connection test failed:', error.message);
            return { success: false, error: error.message };
        }
    }

    async call(func, args) {
        var reply = await this.websocket.sendRequest({func, args});
        if(reply.success) {
            return reply.ret;
        } else {
            throw reply.error;
        }
    }

    async getObject(name) {
        var r = await this.call('wsRemoteApi.info', [name]);
        return this.getObject_(name, r[0]);
    }

    async require(name) {
        await this.call('wsRemoteApi.require', [name]);
        return await this.getObject(name);
    }

    getObject_(name, _info) {
        const client = this;
        var ret = {}
        for(let k in _info) {
            var v = _info[k];
            if(Object.keys(v).length == 1 && v['func'] !== undefined)
                ret[k] = async function(...args) {
                    return await client.call(name + "." + k, args);
                };
            else if(Object.keys(v).length == 1 && v['const'] !== undefined)
                ret[k] = v['const'];
            else
                ret[k] = this.getObject(name + "." + k, null, null, v);
        }
        return ret
    }
}

// Export for both Node.js and Browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RemoteAPIClient;
} else if (typeof window !== 'undefined') {
    window.RemoteAPIClient = RemoteAPIClient;
}
